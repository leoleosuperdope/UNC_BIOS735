library(testthat)
library(ridgeLR)

test_check("ridgeLR")
